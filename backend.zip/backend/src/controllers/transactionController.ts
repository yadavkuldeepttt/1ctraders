import type { Request, Response } from "express"

type ControllerResponse = Response | void
import mongoose from "mongoose"
import { TransactionModel } from "../db/models/TransactionModel"
import { UserModel } from "../db/models/UserModel"
import { createPayment } from "../services/nowpaymentsService"

export const createDeposit = async (req: Request, res: Response): Promise<ControllerResponse> => {
  try {
    const userId = (req as any).userId
    const { amountUSD, coin } = req.body

    // Validate input
    if (!amountUSD || amountUSD <= 0) {
      return res.status(400).json({ error: "Invalid amount" })
    }

    if (!coin) {
      return res.status(400).json({ error: "Coin selection is required" })
    }

    if (!mongoose.Types.ObjectId.isValid(userId)) {
      return res.status(400).json({ error: "Invalid user ID" })
    }

    // Get user
    const user = await UserModel.findById(userId)
    if (!user) {
      return res.status(404).json({ error: "User not found" })
    }

    // Generate unique order ID
    const orderId = `DEP_${Date.now()}_${Math.random().toString(36).substring(2, 9).toUpperCase()}`

    // Create NOWPayments payment
    const paymentResult = await createPayment(
      amountUSD,
      "usd",
      coin.toLowerCase(),
      orderId,
      user.email || ""
    )

    if (!paymentResult.success || !paymentResult.data) {
      return res.status(500).json({
        error: paymentResult.error || "Failed to create payment",
      })
    }

    const paymentData = paymentResult.data

    // Save deposit transaction with NOWPayments data
    const transaction = await TransactionModel.create({
      userId: new mongoose.Types.ObjectId(userId),
      type: "deposit",
      amount: amountUSD,
      status: "pending",
      description: `Deposit via ${coin}`,
      paymentId: paymentData.payment_id,
      coin: coin.toUpperCase(),
      cryptoAmount: parseFloat(paymentData.pay_amount || "0"),
      payAddress: paymentData.pay_address,
      paymentStatus: paymentData.payment_status || "waiting",
    })

    res.status(201).json({
      message: "Deposit payment created",
      transaction: transaction.toJSON(),
      payment: {
        paymentId: paymentData.payment_id,
        payAddress: paymentData.pay_address,
        payAmount: paymentData.pay_amount,
        coin: coin.toUpperCase(),
        amountUSD: amountUSD,
        status: paymentData.payment_status,
      },
    })
  } catch (error) {
    console.error("Create deposit error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
}

export const createWithdrawal = async (req: Request, res: Response): Promise<ControllerResponse> => {
  try {
    const userId = (req as any).userId
    const { amount, withdrawalAddress } = req.body

    if (!amount || amount <= 0) {
      return res.status(400).json({ error: "Invalid amount" })
    }

    if (!withdrawalAddress) {
      return res.status(400).json({ error: "Withdrawal address is required" })
    }

    if (!mongoose.Types.ObjectId.isValid(userId)) {
      return res.status(400).json({ error: "Invalid user ID" })
    }

    // Check user balance
    const user = await UserModel.findById(userId)
    if (!user) {
      return res.status(404).json({ error: "User not found" })
    }

    if (user.balance < amount) {
      return res.status(400).json({ error: "Insufficient balance" })
    }

    const transaction = await TransactionModel.create({
      userId: new mongoose.Types.ObjectId(userId),
      type: "withdrawal",
      amount,
      status: "pending",
      description: "Withdrawal request",
      withdrawalAddress,
    })

    res.status(201).json({
      message: "Withdrawal request created",
      transaction: transaction.toJSON(),
    })
  } catch (error) {
    console.error("Create withdrawal error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
}

export const getUserTransactions = async (req: Request, res: Response): Promise<ControllerResponse> => {
  try {
    const userId = (req as any).userId
    const { type, status, limit = 50 } = req.query

    if (!mongoose.Types.ObjectId.isValid(userId)) {
      return res.status(400).json({ error: "Invalid user ID" })
    }

    const query: any = { userId: new mongoose.Types.ObjectId(userId) }

    if (type) {
      query.type = type
    }

    if (status) {
      query.status = status
    }

    const userTransactions = await TransactionModel.find(query)
      .sort({ createdAt: -1 })
      .limit(Number(limit))

    res.json({
      transactions: userTransactions.map((tx) => tx.toJSON()),
      total: userTransactions.length,
    })
  } catch (error) {
    console.error("Get transactions error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
}

export const getTransactionById = async (req: Request, res: Response): Promise<ControllerResponse> => {
  try {
    const userId = (req as any).userId
    const { id } = req.params

    if (!mongoose.Types.ObjectId.isValid(userId) || !mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ error: "Invalid ID" })
    }

    const transaction = await TransactionModel.findOne({
      _id: new mongoose.Types.ObjectId(id),
      userId: new mongoose.Types.ObjectId(userId),
    })

    if (!transaction) {
      return res.status(404).json({ error: "Transaction not found" })
    }

    res.json(transaction.toJSON())
  } catch (error) {
    console.error("Get transaction error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
}
